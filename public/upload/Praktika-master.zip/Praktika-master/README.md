# Praktika

install project

    clone project
    # git clone https://github.com/MrRouOne/Praktika
    cd Praktika
    composer install 
    
    install requires
    # composer create-project MrRouone/Praktika:dev-master
