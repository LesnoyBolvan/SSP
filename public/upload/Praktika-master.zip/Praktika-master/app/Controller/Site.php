<?php

namespace Controller;

use Model\User;
use Src\View;
use Src\Request;
use Src\Auth\Auth;
use Src\Validator\Validator;

class Site
{
    public static function setSelect($request, string $field): void
    {
        if (!isset($request->all()["$field"])) {
            $request->set("$field", '');
        }
    }

    public function index(Request $request): string
    {
        return (new View())->render('site.index');
    }

    public function error_403(Request $request): string
    {
        return (new View())->render('site.error_403');
    }

    public function signup(Request $request): string
    {
        if ($request->method === 'POST') {

            $validator = new Validator($request->all(), [
                'name' => ['required'],
                'login' => ['required', 'unique:users,login'],
                'password' => ['required']
            ], [
                'required' => 'Поле :field пусто',
                'unique' => 'Поле :field должно быть уникально'
            ]);

            if ($validator->fails()) {
                return (new View())->render('site.signup',
                    ['message' => json_encode($validator->errors(), JSON_UNESCAPED_UNICODE)]);
            }

            if (User::create($request->all())) {
                app()->route->redirect('/login');
                return false;
            }
        }
        return (new View())->render('site.signup');
    }


    public function login(Request $request): string
    {
        //Если просто обращение к странице, то отобразить форму
        if ($request->method === 'GET') {
            return (new View())->render('site.login');
        }
        //Если удалось аутентифицировать пользователя, то редирект
        if (Auth::attempt($request->all())) {
            app()->route->redirect('/');
            return false;
        }
        //Если аутентификация не удалась, то сообщение об ошибке
        return (new View())->render('site.login', ['message' => 'Неправильные логин или пароль']);

    }

    public function logout(): void
    {
        Auth::logout();
        app()->route->redirect('/');
    }
}
