<h1 class="text-center" style="margin-top: 40px;">Объявления</h1>

<div class="card shadow-sm" style="margin-top: 30px;">
    <div class="card-body">
        <h1 class="card-text">Объявление1</h1>
        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. A doloremque ea facilis incidunt
            iure obcaecati quis saepe sint? Adipisci aliquid at debitis delectus earum esse iusto molestiae nam omnis
            porro!Lorem ipsum dolor sit amet, consectetur adipisicing elit. A doloremque ea facilis incidunt
            iure obcaecati quis saepe sint? Adipisci aliquid at debitis delectus earum esse iusto molestiae nam omnis
            porro!Lorem ipsum dolor sit amet, consectetur adipisicing elit. A doloremque ea facilis incidunt
            iure obcaecati quis saepe sint? Adipisci aliquid at debitis delectus earum esse iusto molestiae nam omnis
            porro!Lorem ipsum dolor sit amet, consectetur adipisicing elit. A doloremque ea facilis incidunt
            iure obcaecati quis saepe sint? Adipisci aliquid at debitis delectus earum esse iusto molestiae nam omnis
            porro!</p>
    </div>
</div>
<div class="card shadow-sm" style="margin-top: 30px;">
    <div class="card-body">
        <h1 class="card-text">Объявление2</h1>
        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. A doloremque ea facilis incidunt
            iure obcaecati quis saepe sint? Adipisci aliquid at debitis delectus earum esse iusto molestiae nam omnis
            porro!Lorem ipsum dolor sit amet, consectetur adipisicing elit. A doloremque ea facilis incidunt
            iure obcaecati quis saepe sint? Adipisci aliquid at debitis delectus earum esse iusto molestiae nam omnis
            porro!Lorem ipsum dolor sit amet, consectetur adipisicing elit. A doloremque ea facilis incidunt
            iure obcaecati quis saepe sint? Adipisci aliquid at debitis delectus earum esse iusto molestiae nam omnis
            porro!Lorem ipsum dolor sit amet, consectetur adipisicing elit. A doloremque ea facilis incidunt
            iure obcaecati quis saepe sint? Adipisci aliquid at debitis delectus earum esse iusto molestiae nam omnis
            porro!</p>
    </div>
</div>

<div class="card shadow-sm" style="margin-top: 30px;">
    <div class="card-body">
        <h1 class="card-text">Объявление3</h1>
        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. A doloremque ea facilis incidunt
            iure obcaecati quis saepe sint? Adipisci aliquid at debitis delectus earum esse iusto molestiae nam omnis
            porro!Lorem ipsum dolor sit amet, consectetur adipisicing elit. A doloremque ea facilis incidunt
            iure obcaecati quis saepe sint? Adipisci aliquid at debitis delectus earum esse iusto molestiae nam omnis
            porro!Lorem ipsum dolor sit amet, consectetur adipisicing elit. A doloremque ea facilis incidunt
            iure obcaecati quis saepe sint? Adipisci aliquid at debitis delectus earum esse iusto molestiae nam omnis
            porro!Lorem ipsum dolor sit amet, consectetur adipisicing elit. A doloremque ea facilis incidunt
            iure obcaecati quis saepe sint? Adipisci aliquid at debitis delectus earum esse iusto molestiae nam omnis
            porro!</p>
    </div>
</div>

