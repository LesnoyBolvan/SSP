<?php

function app()
{
    global $app;
    return $app;
}
