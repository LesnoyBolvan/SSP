<div class="text-center text-danger">
    <h1 style="font-size: 60px; margin-top: 40px;">403 ошибка</h1>

    <br><br><br><br><br>

    <h1 style="font-size: 60px;">Доступ запрещён!!!</h1>
</div>
