# Praktika

install project

    clone project
    # git clone https://github.com/MrRouOne/Praktika
    cd Praktika
    install composer
    
    install requires
    # composer create-project MrRouone/Praktika:dev-master
